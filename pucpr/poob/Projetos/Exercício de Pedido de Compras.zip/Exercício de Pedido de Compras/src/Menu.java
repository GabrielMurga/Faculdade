import java.util.Scanner;

public class Menu {

    public Menu(){};
    public Restaurante criarRestaurante(){
        Restaurante restaurante = new Restaurante("Restaurante BCC");

        restaurante.adicionarPratoAoMenu(new Prato(1, "Lasanha", 35.0));
        restaurante.adicionarPratoAoMenu(new Prato(2, "Feijoada", 50.0));
        restaurante.adicionarPratoAoMenu(new Prato(3, "Pizza", 60.0));
        restaurante.adicionarPratoAoMenu(new Prato(4, "Hambúrguer", 25.0));
        restaurante.adicionarPratoAoMenu(new Prato(5, "Arroz", 20.0));
        restaurante.adicionarPratoAoMenu(new Prato(6, "Salada", 15.0));
        return restaurante;
    }
    public int validarCPF(String cpf){
        int cpfValido = 0;
        if (Validador.validarCPF(cpf)){
            cpfValido = 1;
            return cpfValido;}
        else {
            System.out.println("O cpf inserido e invalido! Tente novamente!");
            return cpfValido;}

    }
    public int validarCEP(String cep){
        int cepValido = 0;
        if (Validador.validarCEP(cep)){
            cepValido = 1;
            return cepValido;}
        else {
            System.out.println("O cep inserido e invalido! Tente novamente!");
            return cepValido;}

    }
    public  Cliente cadastrarCliente(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("*** CADASTRAR CLIENTE ***");
        System.out.print("Nome: ");
        String nomeCliente = scanner.nextLine();
        System.out.print("Telefone: ");
        String telefoneCliente = scanner.nextLine();
        System.out.println("CPF");
        String cpfCliente =scanner.nextLine();
        while (validarCPF(cpfCliente)==0){
            System.out.println("CPF");
             cpfCliente =scanner.nextLine();
        };
        System.out.println("CEP");
        String cepCliente = scanner.nextLine();
        while (validarCEP(cepCliente)==0){
            System.out.println("CEP");
            cepCliente =scanner.nextLine();
        }
        Cliente cliente = new Cliente(nomeCliente, telefoneCliente,cpfCliente,cepCliente);
        return cliente;
    }
    public void escolherPrato(Pedido pedido,Restaurante restaurante,Integer codigoPrato){

        Prato prato = restaurante.buscarPrato(codigoPrato);
        if (prato != null) {
            pedido.adicionarPrato(prato);
        } else {
            System.out.println("\nPrato não encontrado, tente novamente.");
        }
    }
    public void removerPrato(Pedido pedido,String resposta){
        Scanner scanner = new Scanner(System.in);
        if (resposta.equalsIgnoreCase("s")) {
            System.out.print("Digite o código do prato a remover: ");
            int codigoPratoRemover = scanner.nextInt();
            scanner.nextLine();
            pedido.removerPrato(codigoPratoRemover);
            System.out.println("Pedido atualizado:");
            pedido.exibirPedido();
        }
    }
    public boolean encerrar(String resposta){
        if (resposta.equalsIgnoreCase("s")) {
            return false;
        }
        return true;
    }
}
