import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Menu menu = new Menu();
        Restaurante restaurante = menu.criarRestaurante();
        Cliente cliente = menu.cadastrarCliente();
        Pedido pedido = new Pedido(cliente);
        restaurante.listarPratos();

        boolean continuar = true;
        while (continuar) {
            System.out.print("\nDigite o código da prato desejado: ");
            int codigoPrato = scanner.nextInt();
            scanner.nextLine();
            menu.escolherPrato(pedido,restaurante,codigoPrato);
            pedido.exibirPedido();
            System.out.print("Deseja remover algum prato? (s/n): ");
            String resposta = scanner.nextLine();
            menu.removerPrato(pedido,resposta);
            System.out.print("Deseja encerrar? (s/n): ");
            String respostaEncerrar = scanner.nextLine();
            continuar = menu.encerrar(respostaEncerrar);
        }

        pedido.exibirPedido();
        scanner.close();
    }
}