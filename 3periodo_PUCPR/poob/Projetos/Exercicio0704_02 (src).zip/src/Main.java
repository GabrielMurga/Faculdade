import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        ArrayList<Animal> listaAnimais = new ArrayList<>();

        int opcao = 0;

        while (opcao != 9) {
            System.out.println("\n*** Clínica Veterinária ***");
            System.out.println("Escolha o animal para atendimento:");
            System.out.println("(1) Cachorro");
            System.out.println("(2) Gato");
            System.out.println("(3) Pássaro");
            System.out.println("(4) Cavalo");
            System.out.println("(5) Vaca");
            System.out.println("(9) Sair");
            System.out.print("    Opção: ");

            opcao = scanner.nextInt();

            if(opcao == 1) {
                listaAnimais.add(new Cachorro());
                System.out.print("\nSom do animal: ");
                listaAnimais.get(listaAnimais.size()-1).som();
            } else if(opcao == 2) {
                listaAnimais.add(new Gato());
                System.out.print("\nSom do animal: ");
                listaAnimais.get(listaAnimais.size()-1).som();
            } else if(opcao == 3) {
                listaAnimais.add(new Passaro());
                System.out.print("\nSom do animal: ");
                listaAnimais.get(listaAnimais.size()-1).som();
            } else if(opcao == 4) {
                listaAnimais.add(new Cavalo());
                System.out.print("\nSom do animal: ");
                listaAnimais.get(listaAnimais.size()-1).som();
            } else if(opcao == 5) {
                listaAnimais.add(new Vaca());
                System.out.print("\nSom do animal: ");
                listaAnimais.get(listaAnimais.size()-1).som();
            } else {
                System.out.println("Opção inválida.");
            }
        }

        scanner.close();
    }
}