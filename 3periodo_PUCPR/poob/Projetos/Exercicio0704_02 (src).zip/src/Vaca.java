class Vaca extends Animal {
    @Override
    void som() {
        System.out.print("Muuuu\n");
    }
}