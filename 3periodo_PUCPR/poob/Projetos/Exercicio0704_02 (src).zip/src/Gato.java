public class Gato extends Animal{

    @Override
    void som() {
        System.out.println("Au Au");
    }
}