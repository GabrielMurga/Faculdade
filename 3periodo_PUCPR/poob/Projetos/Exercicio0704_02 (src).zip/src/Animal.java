abstract class Animal {
    abstract void som();
}
