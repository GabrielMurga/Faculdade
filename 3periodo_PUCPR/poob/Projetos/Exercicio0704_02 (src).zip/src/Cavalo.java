
class Cavalo extends Animal {
    @Override
    void som() {
        System.out.print("Irrrííí\n");
    }
}