public class Cachorro extends Animal{

    @Override
    void som() {
        System.out.print("Au Au\n");
    }
}
