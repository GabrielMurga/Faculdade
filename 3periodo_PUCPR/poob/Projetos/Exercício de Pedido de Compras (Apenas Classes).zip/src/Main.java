import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Restaurante restaurante = new Restaurante("Restaurante BCC");

        restaurante.adicionarPratoAoMenu(new Prato(1, "Lasanha", 35.0));
        restaurante.adicionarPratoAoMenu(new Prato(2, "Feijoada", 50.0));
        restaurante.adicionarPratoAoMenu(new Prato(3, "Pizza", 60.0));
        restaurante.adicionarPratoAoMenu(new Prato(4, "Hambúrguer", 25.0));
        restaurante.adicionarPratoAoMenu(new Prato(5, "Arroz", 20.0));
        restaurante.adicionarPratoAoMenu(new Prato(6, "Salada", 15.0));

        System.out.println("*** CADASTRAR CLIENTE ***");
        System.out.print("Nome: ");
        String nomeCliente = scanner.nextLine();
        System.out.print("Telefone: ");
        String telefoneCliente = scanner.nextLine();
        Cliente cliente = new Cliente(nomeCliente, telefoneCliente);

        Pedido pedido = new Pedido(cliente);

        restaurante.listarPratos();

        boolean continuar = true;
        while (continuar) {
            System.out.print("\nDigite o código da prato desejado: ");
            int codigoPrato = scanner.nextInt();
            scanner.nextLine();
            Prato prato = restaurante.buscarPrato(codigoPrato);
            if (prato != null) {
                pedido.adicionarPrato(prato);
            } else {
                System.out.println("\nPrato não encontrado, tente novamente.");
            }

            pedido.exibirPedido();

            System.out.print("Deseja remover algum prato? (s/n): ");
            String resposta = scanner.nextLine();
            if (resposta.equalsIgnoreCase("s")) {
                System.out.print("Digite o código do prato a remover: ");
                int codigoPratoRemover = scanner.nextInt();
                scanner.nextLine();
                pedido.removerPrato(codigoPratoRemover);
                System.out.println("Pedido atualizado:");
                pedido.exibirPedido();
            }

            System.out.print("Deseja encerrar? (s/n): ");
            String respostaEncerrar = scanner.nextLine();
            if (respostaEncerrar.equalsIgnoreCase("s")) {
                continuar = false;
            }
        }

        pedido.exibirPedido();
        scanner.close();
    }
}