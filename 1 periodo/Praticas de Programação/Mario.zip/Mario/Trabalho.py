
import pygame

def load():
    global montanha, nuvem, chao, cano, px, cloud_x,sys_font, cloud_speed, moving_left,audio_lup,audio_super,icon_1up, icon_super

    pygame.init()
    screen = pygame.display.set_mode((800, 600))
    sys_font = pygame.font.Font(pygame.font.get_default_font(), 20)
    montanha = pygame.image.load('mario_background.png')
    nuvem = pygame.image.load('mario_cloud.png')
    chao = pygame.image.load('mario_ground.png')
    cano_original = pygame.image.load('mario_pipe.png')
    cano = pygame.transform.scale(cano_original, (cano_original.get_width(), cano_original.get_height() // 2))
    icon_1up = pygame.image.load("1up.png")
    icon_super = pygame.image.load("super.png")
    audio_1up = pygame.mixer.Sound("1up.mp3")
    pygame.mixer.music.load("super.mp3")
    px = 0
    cloud_x = 400
    cloud_speed = 0.1

    moving_left = False

def draw_screen(screen):
    screen.fill((172, 229, 251))
    px = 0
    while px < screen.get_width():
        screen.blit(chao, (px, 475))
        px = px + 30
    pxm = 0
    while pxm < screen.get_width():
        screen.blit(montanha, (pxm, 220))
        pxm = pxm + 250
    screen.blit(nuvem, (cloud_x, -10))
    screen.blit(cano, (450, 410))
    screen.blit(icon_1up, (100, 200))
    screen.blit(icon_super, (550, 200))
    t = sys_font.render("Clique para 1up", True, (0,0,0))
    screen.blit(t, (85,170))
    t = sys_font.render("Clique Música", True, (0,0,0))
    screen.blit(t, (545,170))
    t = sys_font.render("Música: i para iniciar, p para pausar, r para despausar, s para parar", True, (0,0,0))
    screen.blit(t, t.get_rect(top = 500, left=800/2 - t.get_width()/2))
def update(dt, screen):
    global cloud_x, moving_left
    if moving_left:
        cloud_x -= cloud_speed * dt
        if cloud_x < 0:
            moving_left = False
    else:
        cloud_x += cloud_speed * dt
        if cloud_x + nuvem.get_width() > screen.get_width():
            moving_left = True
def keyboard_keydown(keys):
    if keys[pygame.K_i]:
        pygame.mixer.music.play()
    elif keys[pygame.K_p]:
        pygame.mixer.music.pause()
    elif keys[pygame.K_r]:
        pygame.mixer.music.unpause()
    elif keys[pygame.K_s]:
        pygame.mixer.music.stop()
def keyboard_keyup(keys):
    pass
def main():
    load()
    screen = pygame.display.get_surface()
    clock = pygame.time.Clock()
    running = True
    while running:
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                running = False
                break
            elif e.type == pygame.KEYDOWN: #detecta o inicio do clique do teclado
                keys = pygame.key.get_pressed()
                keyboard_keydown(keys)
            elif e.type == pygame.KEYUP: #detecta o fim do clique do teclado
                keys = pygame.key.get_pressed()
                keyboard_keyup(keys)
        dt = clock.tick(60)
        update(dt, screen)  # Passe 'screen' como argumento
        pygame.display.update()
        draw_screen(screen)
        pygame.display.flip()

    pygame.quit()

if __name__ == "__main__":
    main()

